
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// site/netlify/functions/sor.mjs
var config = { path: "/api/sor" };
var MODEL = "openai/gpt-oss-20b";
var MAX_QUESTION = 400;
var sor_default = async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: cors() });
  }
  if (req.method !== "POST") {
    return json({ error: "Y\xF6ntem desteklenmiyor." }, 405);
  }
  const key = process.env.GROQ_API_KEY;
  if (!key) return json({ error: "Servis yap\u0131land\u0131r\u0131lmam\u0131\u015F." }, 500);
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Ge\xE7ersiz istek." }, 400);
  }
  const question = String(body?.question || "").trim().slice(0, MAX_QUESTION);
  if (question.length < 3) return json({ error: "L\xFCtfen bir soru yaz\u0131n." }, 400);
  const title = String(body?.title || "").slice(0, 220);
  const summary = String(body?.summary || "").slice(0, 900);
  const keyPoints = String(body?.keyPoints || "").slice(0, 600);
  const comment = String(body?.comment || "").slice(0, 900);
  try {
    const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`
      },
      body: JSON.stringify({
        model: MODEL,
        temperature: 0.4,
        max_tokens: 450,
        messages: [
          {
            role: "system",
            content: "Sen HaberAI'nin haber asistan\u0131s\u0131n. Yaln\u0131zca sana verilen haber ba\u011Flam\u0131na dayanarak T\xFCrk\xE7e, k\u0131sa (en fazla 4 c\xFCmle) ve net yan\u0131t ver. Ba\u011Flamda olmayan bilgiyi uydurma; emin de\u011Filsen bunu a\xE7\u0131k\xE7a s\xF6yle."
          },
          {
            role: "user",
            content: `HABER BA\u015ELI\u011EI: ${title}
HABER \xD6ZET\u0130: ${summary}
\xD6NE \xC7IKANLAR: ${keyPoints || "-"}
ED\u0130T\xD6R YORUMU: ${comment}

KULLANICI SORUSU: ${question}`
          }
        ]
      }),
      signal: AbortSignal.timeout(25e3)
    });
    if (!res.ok) {
      return json({ error: "AI \u015Fu an yan\u0131t veremiyor, birazdan tekrar dene." }, 502);
    }
    const data = await res.json();
    const answer = data?.choices?.[0]?.message?.content?.trim();
    if (!answer) return json({ error: "Yan\u0131t \xFCretilemedi." }, 502);
    return json({ answer });
  } catch {
    return json({ error: "Ba\u011Flant\u0131 hatas\u0131, birazdan tekrar dene." }, 504);
  }
};
function cors() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Max-Age": "86400"
  };
}
function json(obj, status = 200) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...cors() }
  });
}
export {
  config,
  sor_default as default
};
